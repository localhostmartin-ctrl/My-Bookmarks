from flask import Flask, render_template, request, jsonify, redirect, url_for, Response
import sqlite3
import requests
from bs4 import BeautifulSoup
import os
import time
import re

app = Flask(__name__)
DB_FILE = 'bookmarks.db'

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS folders
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  name TEXT NOT NULL,
                  parent_id INTEGER DEFAULT 0,
                  sort_order INTEGER DEFAULT 0)''')
                  
    c.execute('''CREATE TABLE IF NOT EXISTS bookmarks
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  url TEXT NOT NULL,
                  title TEXT NOT NULL,
                  description TEXT DEFAULT '',
                  folder_id INTEGER,
                  sort_order INTEGER DEFAULT 0,
                  FOREIGN KEY(folder_id) REFERENCES folders(id))''')
                  
    try: c.execute('ALTER TABLE folders ADD COLUMN sort_order INTEGER DEFAULT 0')
    except sqlite3.OperationalError: pass
        
    try: c.execute('ALTER TABLE bookmarks ADD COLUMN description TEXT DEFAULT ""')
    except sqlite3.OperationalError: pass

    try: c.execute('ALTER TABLE bookmarks ADD COLUMN sort_order INTEGER DEFAULT 0')
    except sqlite3.OperationalError: pass
    
    c.execute('SELECT count(*) FROM folders')
    if c.fetchone()[0] == 0:
        c.execute('INSERT INTO folders (name, parent_id, sort_order) VALUES (?, ?, ?)', ('默认收藏夹', 0, 0))
    
    conn.commit()
    conn.close()

def get_db_connection():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def fetch_title(url):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
        }
        response = requests.get(url, headers=headers, timeout=5)
        response.encoding = response.apparent_encoding
        soup = BeautifulSoup(response.text, 'html.parser')
        if soup.title and soup.title.string:
            return soup.title.string.strip() or ""
        return ""
    except Exception:
        return ""

@app.route('/')
def home():
    current_folder_id = request.args.get('folder_id', 1, type=int)
    conn = get_db_connection()
    folders = conn.execute('SELECT * FROM folders ORDER BY sort_order ASC, id ASC').fetchall()
    
    if current_folder_id == 0:
        bookmarks = conn.execute('SELECT * FROM bookmarks ORDER BY sort_order ASC, id DESC').fetchall()
    else:
        bookmarks = conn.execute('SELECT * FROM bookmarks WHERE folder_id = ? ORDER BY sort_order ASC, id DESC', (current_folder_id,)).fetchall()
    
    current_folder = conn.execute('SELECT * FROM folders WHERE id = ?', (current_folder_id,)).fetchone()
    conn.close()
    return render_template('index.html', folders=folders, bookmarks=bookmarks, current_folder=current_folder)

@app.route('/add_bookmark', methods=['POST'])
def add_bookmark():
    url = request.form.get('url').strip()
    folder_id = request.form.get('folder_id', 1, type=int)
    if url:
        if not url.startswith(('http://', 'https://')): url = 'https://' + url
        title = fetch_title(url) or "未命名网页 (请修改)"
        conn = get_db_connection()
        max_order = conn.execute('SELECT MAX(sort_order) FROM bookmarks WHERE folder_id = ?', (folder_id,)).fetchone()[0]
        sort_order = (max_order or 0) + 1
        conn.execute('INSERT INTO bookmarks (url, title, folder_id, description, sort_order) VALUES (?, ?, ?, ?, ?)', 
                     (url, title, folder_id, '', sort_order))
        conn.commit()
        conn.close()
    return redirect(url_for('home', folder_id=folder_id))

@app.route('/edit_bookmark/<int:id>', methods=['POST'])
def edit_bookmark(id):
    title = request.form.get('title').strip()
    url = request.form.get('url').strip()
    description = request.form.get('description', '').strip()
    conn = get_db_connection()
    current_bookmark = conn.execute('SELECT folder_id FROM bookmarks WHERE id = ?', (id,)).fetchone()
    folder_id = current_bookmark['folder_id'] if current_bookmark else 1
    conn.execute('UPDATE bookmarks SET title = ?, url = ?, description = ? WHERE id = ?', (title, url, description, id))
    conn.commit()
    conn.close()
    return redirect(url_for('home', folder_id=folder_id))

@app.route('/delete_bookmark/<int:id>', methods=['POST'])
def delete_bookmark(id):
    conn = get_db_connection()
    current_bookmark = conn.execute('SELECT folder_id FROM bookmarks WHERE id = ?', (id,)).fetchone()
    folder_id = current_bookmark['folder_id'] if current_bookmark else 1
    conn.execute('DELETE FROM bookmarks WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('home', folder_id=folder_id))

@app.route('/move_bookmark', methods=['POST'])
def move_bookmark():
    data = request.get_json()
    bookmark_id = data.get('bookmark_id')
    new_folder_id = data.get('new_folder_id')
    if bookmark_id and new_folder_id:
        conn = get_db_connection()
        max_order = conn.execute('SELECT MAX(sort_order) FROM bookmarks WHERE folder_id = ?', (new_folder_id,)).fetchone()[0]
        sort_order = (max_order or 0) + 1
        conn.execute('UPDATE bookmarks SET folder_id = ?, sort_order = ? WHERE id = ?', (new_folder_id, sort_order, bookmark_id))
        conn.commit()
        conn.close()
        return jsonify({'status': 'success'})
    return jsonify({'error': 'Missing data'}), 400

@app.route('/add_folder', methods=['POST'])
def add_folder():
    name = request.form.get('name').strip()
    parent_id = request.form.get('parent_id', 0, type=int)
    if name:
        conn = get_db_connection()
        max_order = conn.execute('SELECT MAX(sort_order) FROM folders WHERE parent_id = ?', (parent_id,)).fetchone()[0]
        sort_order = (max_order or 0) + 1
        conn.execute('INSERT INTO folders (name, parent_id, sort_order) VALUES (?, ?, ?)', (name, parent_id, sort_order))
        conn.commit()
        conn.close()
    return redirect(url_for('home'))

@app.route('/edit_folder/<int:id>', methods=['POST'])
def edit_folder(id):
    name = request.form.get('name').strip()
    conn = get_db_connection()
    if id != 1 and name:
        conn.execute('UPDATE folders SET name = ? WHERE id = ?', (name, id))
        conn.commit()
    conn.close()
    return redirect(url_for('home', folder_id=id))

@app.route('/delete_folder/<int:id>', methods=['POST'])
def delete_folder(id):
    if id == 1: return redirect(url_for('home'))
    conn = get_db_connection()
    conn.execute('UPDATE bookmarks SET folder_id = 1 WHERE folder_id = ?', (id,))
    conn.execute('DELETE FROM folders WHERE parent_id = ?', (id,)) 
    conn.execute('DELETE FROM folders WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('home', folder_id=1))

@app.route('/api/update_order', methods=['POST'])
def update_order():
    data = request.get_json()
    item_type = data.get('type')
    items = data.get('items')
    parent_id = data.get('parent_id')
    
    if items and item_type in ['folder', 'bookmark']:
        conn = get_db_connection()
        table = 'folders' if item_type == 'folder' else 'bookmarks'
        for item in items:
            if item_type == 'folder' and parent_id is not None:
                if int(item['id']) != 1:
                    conn.execute(f'UPDATE {table} SET sort_order = ?, parent_id = ? WHERE id = ?', (item['order'], parent_id, item['id']))
            else:
                conn.execute(f'UPDATE {table} SET sort_order = ? WHERE id = ?', (item['order'], item['id']))
        conn.commit()
        conn.close()
        return jsonify({'status': 'success'})
    return jsonify({'error': 'Invalid data'}), 400

@app.route('/export_html')
def export_html():
    conn = get_db_connection()
    folders = conn.execute('SELECT * FROM folders ORDER BY sort_order ASC').fetchall()
    bookmarks = conn.execute('SELECT * FROM bookmarks ORDER BY sort_order ASC').fetchall()
    conn.close()

    html = ['<!DOCTYPE NETSCAPE-Bookmark-file-1>',
            '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">',
            '<TITLE>Bookmarks</TITLE>',
            '<H1>Bookmarks</H1>',
            '<DL><p>']
    def build_tree(parent_id, indent):
        for f in [f for f in folders if f['parent_id'] == parent_id]:
            html.append(f"{indent}<DT><H3>{f['name']}</H3>")
            html.append(f"{indent}<DL><p>")
            for b in [b for b in bookmarks if b['folder_id'] == f['id']]:
                html.append(f"{indent}    <DT><A HREF=\"{b['url']}\">{b['title']}</A>")
            build_tree(f['id'], indent + "    ")
            html.append(f"{indent}</DL><p>")
    build_tree(0, "    ") 
    html.append('</DL><p>')
    return Response("\n".join(html), mimetype='text/html', headers={'Content-Disposition': 'attachment;filename=bookmarks.html'})

@app.route('/import_html', methods=['POST'])
def import_html():
    if 'file' not in request.files: return redirect(url_for('home'))
    file = request.files['file']
    if file.filename == '': return redirect(url_for('home'))
        
    try:
        content = file.read().decode('utf-8')
        conn = get_db_connection()
        import_folder_name = f"Chrome 导入 ({time.strftime('%Y-%m-%d %H:%M')})"
        conn.execute('INSERT INTO folders (name, parent_id, sort_order) VALUES (?, 0, 999)', (import_folder_name,))
        root_folder_id = conn.execute('SELECT last_insert_rowid()').fetchone()[0]
        folder_stack = [root_folder_id]
        
        for line in content.splitlines():
            line = line.strip()
            if not line: continue
            if '</DL>' in line.upper():
                if len(folder_stack) > 1: folder_stack.pop()
                    
            h3_match = re.search(r'<H3[^>]*>([^<]+)</H3>', line, re.IGNORECASE)
            if h3_match:
                folder_name = h3_match.group(1).strip()
                conn.execute('INSERT INTO folders (name, parent_id, sort_order) VALUES (?, ?, ?)', (folder_name, folder_stack[-1], 999))
                new_folder_id = conn.execute('SELECT last_insert_rowid()').fetchone()[0]
                folder_stack.append(new_folder_id)
                continue
                
            a_match = re.search(r'<A HREF="([^"]+)"[^>]*>([^<]*)</A>', line, re.IGNORECASE)
            if a_match:
                url = a_match.group(1).strip()
                title = a_match.group(2).strip() or url
                conn.execute('INSERT INTO bookmarks (url, title, folder_id, description, sort_order) VALUES (?, ?, ?, ?, ?)', 
                             (url, title, folder_stack[-1], '', 999))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Import failed: {e}")
    return redirect(url_for('home'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5668)